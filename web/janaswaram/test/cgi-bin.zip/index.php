<?php
  //namespace MicrosoftAzure\Storage\Common;
	require 'PHPMailer/PHPMailerAutoload.php';
	//require_once "vendor/autoload.php";
	//use MicrosoftAzure\Storage\Common\ServicesBuilder;
	//use MicrosoftAzure\Storage\Common\ServiceException;
	//use MicrosoftAzure\Storage\Table\Models\BatchOperations;
	//use MicrosoftAzure\Storage\Table\Models\Entity;
	//use MicrosoftAzure\Storage\Table\Models\EdmType;
	//use MicrosoftAzure\Storage\Blob\Models\CreateContainerOptions;
	//use MicrosoftAzure\Storage\Blob\Models\PublicAccessType;
	//$connectionString = 'DefaultEndpointsProtocol=https;AccountName=janasena;AccountKey=QkH/Re3bv4wTVKnZPckcfYPf8dZpWZ55a1CH6A3sYJVg5Blf8VGDNqbagVGWyHy1s1RPAGhSw9XMNDVye+hnFw==;';
	//$tableClient = ServicesBuilder::getInstance()->createTableService($connectionString);
	//$blobClient = ServicesBuilder::getInstance()->createBlobService($connectionString);
	

  // define variables and set to empty values
         $nameErr = $proffessionErr = $emailErr = $phonenoErr = $policyErr = $suggestionErr="";
         $name = $Profession = $email = $phoneno = $policy = $suggestion= "";
         
         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
         
         

         
         function valid_email($email) 
	{
	    if(is_array($email) || is_numeric($email) || is_bool($email) || is_float($email) || is_file($email) || is_dir($email) || is_int($email))
	        return false;
	    else
	    {
	        $email=trim(strtolower($email));
	        if(filter_var($email, FILTER_VALIDATE_EMAIL)===true) return $email;
	        else
	        {
	            $pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';
	            return (preg_match($pattern, $email) === 1) ? $email : false;
	        }
	    }
	}
	
	$allowed = array("image/jpeg", "image/gif", "application/pdf");
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
         
            if (empty($_POST["name"])) {
               $nameErr = "Name is required";
            }            
            else if (empty($_POST["Profession"])) {
               $proffessionErr = "Profession is required";
            }            
            else if (empty($_POST["email"])) {
               $emailErr = "Email is required";
            }  
           else if (!valid_email($_POST["email"])) {
                  $emailErr = "Invalid email format"; 
            }
            else if (empty($_POST["phoneno"])) {
               $phonenoErr = "Phone Number is required";
            }            
            else if (empty($_POST["policy"])) {
               $policyErr = "Policy is required";
            }
            else if (empty($_POST["suggestion"])) {
               $suggestionErr = "Suggestion is required";
            }
            else {
            	//if($tableClient,$blobClient){
            	
	                $name = test_input($_POST["name"]);
	            	$Profession = test_input($_POST["Profession"]);
	            	$email = test_input($_POST["email"]);
	            	$phoneno = test_input($_POST["phoneno"]);
	            	$policy = test_input($_POST["policy"]);
	               	$suggestion = test_input($_POST["suggestion"]);
	               //	$i = uniqid();
	               	
	               	
	               	
	              /* 	$entity = new Entity();
		        $entity->setPartitionKey("pk");
		        $entity->setRowKey($i);
		        $entity->addProperty("Name", EdmType::STRING, $name);
		        $entity->addProperty("Profession", EdmType::STRING, $Profession);
		        $entity->addProperty("Phone", EdmType::STRING, $phoneno);
		        $entity->addProperty("Policy", EdmType::STRING, $policy);
		        $entity->addProperty("Suggestion", EdmType::STRING, $suggestion);
		
		
		        try{
		            $tableClient->insertEntity("Janasena", $entity);
		        }
		        catch(ServiceException $e){
		            $code = $e->getCode();
		            $error_message = $e->getMessage();
		            echo $code.": ".$error_message.PHP_EOL;
		        }
		    */
	               	
	               	
	               	$mail = new PHPMailer;
	       		$mail_us = new PHPMailer;
	       		
	       		//------sends email to our email with the inforamtion sent by user ---
	    
			    $mail_us->setFrom($email, $name );
			    
			    $mail_us->AddReplyTo( $email, $name );
			    
			    $mail_us->Sender = $email;
			    $mail_us->addAddress('janaswaram@janasenaparty.org','Janasena Party');
			    //$mail_us->addAddress('tagore090574@gmail.com','Janasena Party');
			    $mail_us->Subject = $policy;
			    //$mail_us->Body = html_entity_decode($name."<br>".$email."<br>".$phoneno."<br>".$Profession."<br>".$policy."<br>".$suggestion);
			    $mail_us->Body = html_entity_decode('<html><head></head><body><table cellspacing="10" style="margin: 0 auto;font-family: sans-serif;font-size:16px;"><tr><td><b>Name</b></td><td>:</td><td>'.$name.'</td></tr><tr><td><b>Profession</b></td><td>:</td><td>'.$Profession.'</td></tr><tr><td><b>Email Address</b></td><td>:</td><td>'.$email.'</td></tr><tr><td><b>Mobile No</b></td><td>:</td><td>'.$phoneno.'</td></tr><tr><td><b>Policy Issues</b></td><td>:</td><td>'.$policy.'</td></tr><tr><td><b>Suggestion/Opinion/Idea</b></td><td>:</td><td>'.$suggestion.'</td></tr></table></body></html>');
			    $mail_us->IsHTML(true);
			    
			 //----- Thank you emai sends to user email----
			    $mail->setFrom('janaswaram@janasenaparty.org', 'Janasena Party');
			    $mail->AddReplyTo( $email, $name );
			    $mail->Sender = 'janaswaram@janasenaparty.org';
			    $mail->addAddress($email, $name);
			    $mail->Subject = "Janasena Party | Thank you ";
			    $mail->Body = html_entity_decode('<html><head></head><body><table style="margin: 0 auto;text-align: center;font-family: sans-serif;"><tr><td colspan="3"><p style="font-size: 5em;">Thank you</p></td></tr><tr><td colspan="3"><p>we will reach you soon...</p></td></tr><tr><td colspan="3"><img src="http://janasenaparty.org/janaswaram/test/img/pic2.png"></td></tr><tr><td colspan="3" style="border-bottom: 1px dotted #cdcdcd;padding:10px;">Follow us</td></tr><tr><td style="padding:10px;"><a href="https://www.facebook.com/thejanasenaparty/" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/facebook.png"></a><br>Facebook</td><td style="padding:10px;"><a href="https://m.youtube.com/channel/UCrKevLQTcgUp2kZ-WE0pWZQ" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/youtube.png"></a><br>YouTube</td><td style="padding:10px;"><a href="https://twitter.com/thejanasena" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/twitter.png"></a><br>Twitter</td></tr></table></body></html>');
			    $mail->IsHTML(true);
			    
			    if(!file_exists($_FILES['userfile']['tmp_name']) || !is_uploaded_file($_FILES['userfile']['tmp_name'])) {
				    //echo 'No upload';
			    }else{		    
				$uploadfile = tempnam(sys_get_temp_dir(), sha1($_FILES['userfile']['name']));
			    	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
			    			//echo "<br>tagore 2</br>";
		    				$mail_us->addAttachment($uploadfile, 'uploaded file');
		    				//$content = $uploadfile;
				            	//$blob_name = $_FILES['userfile']['name'];
					          //  try {
					                //Upload blob
					             //   $blobClient->createBlockBlob("janasena", $blob_name, $content);
					           // }
					           // catch(ServiceException $e){
					           //     $code = $e->getCode();
					           //     $error_message = $e->getMessage();
					            //    echo $code.": ".$error_message."<br />";
					            //}
			    	}
			    }
			    
			    
			    //$mail->send();
			    //$mail_us->send();
			    
			    if($mail->send() && $mail_us->send()){
				    header('Location: success.php');
				    exit;
			    }
			    
			    
			    
		    
       		//}
            }
         }
         
?>
<html>
    <head>
       
        <title>Janaswaram | jansenaparty.org</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Tagore Navabothu">     
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
         <link rel="stylesheet" href="css/intlTelInput.css">
        <link rel="stylesheet" href="css/demo.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js" ></script> 
	<!--<link rel="stylesheet" href="css/bootstrap.css">-->
       <!-- Latest compiled and minified CSS -->

	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>	
         <script src="js/intlTelInput.js"></script>
        
	<style>
	body{
	background: #fefefe;
	margin:0;
	}
	.container{
	background: white;
	    -webkit-box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
    -moz-box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
    box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
}
	h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-weight: 300;
    line-height: 1.1;
    color: inherit;
}
body {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    
}
	.form-area
	{
	    background-color: #FAFAFA;
	    padding: 10px 40px 60px;
	}
	.banner{  margin: 0 auto; background:url('banner.png'); background-repeat: no-repeat; background-attachment:absolute; }
	.banner { height: 250px; display:block; padding-top:0px; }
        .form-control:focus {
  border-color: #FF0000;
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(255, 0, 0, 0.6);
}
        .form-control {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #FD2C2B;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }
        .error-text{
          color: red;
        }
	</style>
    </head>
    <body>
      
        <div class="container">
        <div class="row">
       <img src="img/Layer45.png" style="width:100%" />
        </div>
        
         <div class="row" style="background: #d81615;color:#fff;">
             <div class="col-md-12">
                  <h4><b>Janasena Party welcomes public participation in policy making !!</b></h4>
                <h4><b>We appreciate suggestions, opinions & ideas of public from all walks of life.</b></h4>
                
             </div>
       

</div>
            <br><br>
        <form method="post" enctype="multipart/form-data" autocomplete="off">
                
        <div class="row">
            <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="name">Name <span class="error-text"><?php echo " * ".$nameErr;?></span></label>
                <input type="text" name="name" class="form-control" id="name" required>
              </div>
            </div>
		   <div class="col-md-6 col-sm-6">
              <div class="form-group">

                <label for="Profession" class=" control-label">Profession <span class="error-text"><?php echo " * ".$proffessionErr;?></span></label><br>
                  <select name="Profession" id="Profession" class="form-control" required>
                    <option value="" selected>Select One</option>
                    <option value="Academician">Academician</option>
                    <option value="Student">Student</option>
                    <option value="Self-employed">Self-employed</option>
                    <option value="house wife">house wife</option>
                    <option value="Journalist">Journalist</option>
                    <option value="other">other</option>
                </select>
              </div>
		  </div>
        </div>
		   
	   <div class="row">
		  <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="email">Email Address <span class="error-text"><?php echo " * ".$emailErr;?></span></label>
                <input type="email" name="email" class="form-control" id="email" required>
              </div>
		  </div>
		  <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="phoneno">Phone Number <span class="error-text"><?php echo " * ".$phonenoErr;?></span></label>
                <input type="text" name="phoneno" class="form-control" maxlength=15 id="phone" required>
              </div>
		  </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label for="policy">Policy Issues <span class="error-text"><?php echo " * ".$policyErr;?></span></label>
                  <select name="policy" class="form-control" required>
                    <option value="" selected>Select One</option>
                    <option value="Land Policy">Land Policy</option>
                    <option value="Mining">Mining</option>
                    <option value="Nuclear Energy">Nuclear Energy</option>
                    <option value="Youth in Politics">Youth in Politics</option>
                    <option value="Education">Education</option>
                </select>
              </div>
            </div>
        </div>
        <div class="row">
		  <div class="col-md-12">
              <div class="form-group">

                <label for="suggestion">Suggestion/Opinion/Idea <span class="error-text"><?php echo " * ".$suggestionErr;?></span></label>
                <textarea class="form-control" rows="4" cols="50" required="required" aria-required="true" name="suggestion"></textarea>
              </div>
		  </div>
        </div>
            <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="file">Attachments :</label>
                    <input type="hidden" name="MAX_FILE_SIZE" value="10000000"> Send this file: <input class="form-control" name="userfile" type="file" accept=
        "application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint,
        text/plain, application/pdf ">
                  </div>
                </div>
            </div>
		  <div class="row">
            
		  <div class="col-md-12" style="text-align:center;">		 
		  <input type="submit" class="btn btn-danger btn-lg" value="Submit">
		  </div>
		  <br><br>
        </div>
		</form>
        		
        	
        </div>

        
        <script>
  jQuery(document).ready(function() {
                jQuery("#submit").click(function() {
                    var sen_email = jQuery('.sen_email').val();
                    var rec_email = jQuery('.rec_email').val();
                    if (sen_email == "") {
                        alert('Sender\'s Email Address cannot be empty.');
                    }
                     if (rec_email == "") {
                        alert('Receiver\'s Email Address cannot be empty.');
                    }
                });
            });
        </script>
     <script>
    $("#phone").intlTelInput({
    allowExtensions: false,
      // allowDropdown: false,
      // autoHideDialCode: false,
       	autoPlaceholder: "off",
       	autoHideDialCode: false,
   	autoPlaceholder: false,
   	nationalMode: false,
      // dropdownContainer: "body",
      // excludeCountries: ["IN"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
       initialCountry: "IN",
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
       preferredCountries: ['IN','US','UK'],
      // separateDialCode: true,
      utilsScript: "js/utils.js"
    });
  </script>
    </body>
</html>