<html>
	<head>
		
	</head>
	<body>
		<table style="margin: 0 auto;text-align: center;font-family: sans-serif;">

		<tr>
			
			<td colspan="3"><p style="font-size: 5em;">Thank you</p></td>
		</tr>
		<tr>
			<td colspan="3">We will reach you soon...</td>
		</tr>
		
			<tr>
				<td colspan="3"><img src="http://janasenaparty.org/janaswaram/test/img/pic2.png"></td>
				
			</tr>

			<tr>
				<td colspan="3" style="border-bottom: 1px dotted #cdcdcd;padding:10px;">Follow us</td>
			</tr>
			<tr>
				<td style="padding:10px;"><a href="https://www.facebook.com/thejanasenaparty/" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/facebook.png"></a><br>Facebook</td>
				<td style="padding:10px;"><a href="https://m.youtube.com/channel/UCrKevLQTcgUp2kZ-WE0pWZQ" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/youtube.png"></a><br>YouTube</td>
				<td style="padding:10px;"><a href="https://twitter.com/thejanasena" target="_blank"><img src="http://janasenaparty.org/janaswaram/test/img/social-icons/twitter.png"></a><br>Twitter</td>
			</tr>
			
		</table>
	</body>
</html>