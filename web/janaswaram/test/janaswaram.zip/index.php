<?php
//echo "name".$_POST['name']."<br>";

if(isset($_POST['name'])) {
	require 'PHPMailer/PHPMailerAutoload.php';
       $mail = new PHPMailer;
       $mail_us = new PHPMailer;
        
	$name = $_POST['name'];
    	$Profession = $_POST['Profession'];
    	$email = $_POST['email'];
    	$name = $_POST['name'];
    	$phoneno = $_POST['phoneno'];
    	$policy = $_POST['policy'];
    	$suggestion = $_POST['suggestion'];
    	//$file = $_POST['file'];
    	
    	//echo $name;
    	//echo $Profession;
    	//echo $email;
    	//echo $name;
    	//echo $phoneno;
    	//echo $policy;
    	//echo $suggestion;
    	//
    	
    	//------sends email to our email with the inforamtion sent by user ---
    	
       $mail_us->setFrom($email, $name );
       
       $mail_us->AddReplyTo( $email, $name );
       
       $mail_us->Sender = $email;
       $mail_us->addAddress('janaswaram@janasenaparty.org','Janasena Party');
       $mail_us->Subject = $policy;
       $mail_us->Body = html_entity_decode($name."<br>".$email."<br>".$phoneno."<br>".$Profession."<br>".$policy."<br>".$suggestion);
       $mail_us->IsHTML(true);
    	
    	//----- Thank you emai sends to user email----
       $mail->setFrom('janaswaram@janasenaparty.org', 'Janasena Party');
       $mail->AddReplyTo( $email, $name );
       $mail->Sender = 'janaswaram@janasenaparty.org';
       $mail->addAddress($email, $name);
       $mail->Subject = "Janasena Party | Thank you ";
       $mail->Body = html_entity_decode('Thank you');
       $mail->IsHTML(true);
    	//echo "1";
    	
    	if(!file_exists($_FILES['userfile']['tmp_name']) || !is_uploaded_file($_FILES['userfile']['tmp_name'])) {
    //echo 'No upload';
}else{
	$uploadfile = tempnam(sys_get_temp_dir(), sha1($_FILES['userfile']['name']));
    		if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    			//echo "<br>tagore 2</br>";
    			$mail_us->addAttachment($uploadfile, 'uploaded file');
    		}
}
    	
    	/*if (array_key_exists('file', $_FILES)) {
    			echo "<br>tagore 1<br>";
    		$uploadfile = tempnam(sys_get_temp_dir(), sha1($_FILES['userfile']['name']));
    		if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    			echo "<br>tagore 2</br>";
    			$mail->addAttachment($uploadfile, 'uploaded file');
    		}
    	
    	}else{
    	echo "<br>tagore 3<br>";
    	}*/
    	//echo "2";
    	
    	if (!$mail->send()) {
            $msg .= "Mailer Error: " . $mail->ErrorInfo;
           // echo $msg;
       } else {
       
            $msg .= "Message sent!";
           // echo $msg;
           // header('Location: '.$_SERVER['REQUEST_URI']);
        }
        
        //---- to us ----
        if (!$mail_us->send()) {
            $msg .= "Mailer Error: " . $mail->ErrorInfo;
           // echo $msg;
       } else {
       
            $msg .= "Message sent!";
           // echo $msg;
           // header('Location: '.$_SERVER['REQUEST_URI']);
        }
        header('Location: '.$_SERVER['REQUEST_URI']);
        
}else{
//echo "no post found";
}

?>
<html>
    <head>
       
        <title>Janaswaram | jansenaparty.org</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="ISO-8859-1">
        <!--<link rel="stylesheet" type="text/css" href="css/style.css"/>-->
        
         <link rel="stylesheet" href="css/intlTelInput.css">
        <link rel="stylesheet" href="css/demo.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js" ></script> 
	<!--<link rel="stylesheet" href="css/bootstrap.css">-->
       <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>	
         <script src="js/intlTelInput.js"></script>
        
	<style>
	body{
	background: #fefefe
	}
	.container{
	background: white;
	    -webkit-box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
    -moz-box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
    box-shadow: 1px 1px 10px 5px rgba(160, 160, 160, 0.53);
}
	h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-weight: 300;
    line-height: 1.1;
    color: inherit;
}
body {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    
}
	.form-area
{
    background-color: #FAFAFA;
	padding: 10px 40px 60px;
	}
	.banner{  margin: 0 auto; background:url('banner.png'); background-repeat: no-repeat; background-attachment:absolute; }
	.banner { height: 250px; display:block; padding-top:0px; }
        .form-control:focus {
  border-color: #FF0000;
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(255, 0, 0, 0.6);
}
        .form-control {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #FD2C2B;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }
	</style>
    </head>
    <body>
      
        <div class="container">
        <div class="row">
       <img src="img/Layer45.png" style="width:100%" />
        </div>
        
         <div class="row" style="background: #d81615;color:#fff;text-align:center;">
             <div class="col-md-12">
                  <h4><b>Janasena Party welcomes public participation in policy making !!</b></h4>
                <h4><b>We appreciate suggestions, opinions & ideas of public from all walks of life.</b></h4>
                
             </div>
       

</div>
            <br><br>
        <form method="post" enctype="multipart/form-data">
                
        <div class="row">
            <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" class="form-control" id="name" required>
              </div>
            </div>
		   <div class="col-md-6 col-sm-6">
              <div class="form-group">

                <label for="Profession" class=" control-label">Profession:</label><br>
                  <select name="Profession" id="Profession" class="form-control" required>
                    <option value="" selected>Select One</option>
                    <option value="Academician">Academician</option>
                    <option value="Student">Student</option>
                    <option value="Self-employed">Self-employed</option>
                    <option value="house wife">house wife</option>
                    <option value="Journalist">Journalist</option>
                    <option value="other">other</option>
                </select>
              </div>
		  </div>
        </div>
		   
	   <div class="row">
		  <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" name="email" class="form-control" id="email" required>
              </div>
		  </div>
		  <div class="col-md-6 col-sm-6">
              <div class="form-group">
                <label for="phoneno">Phone Number :</label>
                <input type="text" name="phoneno" class="form-control" maxlength=10 id="phone" required>
              </div>
		  </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label for="policy">Policy Issues:</label>
                  <select name="policy" class="form-control" required>
                    <option value="" selected>Select One</option>
                    <option value="Land Policy">Land Policy</option>
                    <option value="Mining">Mining</option>
                    <option value="Nuclear Energy">Nuclear Energy</option>
                    <option value="Youth in Politics">Youth in Politics</option>
                    <option value="Education">Education</option>
                </select>
              </div>
            </div>
        </div>
        <div class="row">
		  <div class="col-md-12">
              <div class="form-group">

                <label for="suggestion">Suggestion/Opinion/Idea:</label>
                <textarea class="form-control" rows="4" cols="50" required="required" aria-required="true" name="suggestion"></textarea>
              </div>
		  </div>
        </div>
            <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="file">Attachments :</label>
                    <input type="hidden" name="MAX_FILE_SIZE" value="10000000"> Send this file: <input name="userfile" type="file">
                    <!--<input type="file" name="file" class="form-control" id="file" accept=
        "application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint,
        text/plain, application/pdf ">-->
                  </div>
                </div>
            </div>
		  <div class="row">
            
		  <div class="col-md-12" style="text-align:center;">		 
		  <input type="submit" class="btn btn-danger btn-lg" onclick="checkdata()"></button>
		  </div>
        </div>
		</form>
        		
        	
        </div>

            <div id="note">
               
            </div>
        </div>
        <script>
  jQuery(document).ready(function() {
                jQuery("#submit").click(function() {
                    var sen_email = jQuery('.sen_email').val();
                    var rec_email = jQuery('.rec_email').val();
                    if (sen_email == "") {
                        alert('Sender\'s Email Address cannot be empty.');
                    }
                     if (rec_email == "") {
                        alert('Receiver\'s Email Address cannot be empty.');
                    }
                });
            });
        </script>
     <script>
    $("#phone").intlTelInput({
      // allowDropdown: false,
      // autoHideDialCode: false,
       autoPlaceholder: "off",
      // dropdownContainer: "body",
      // excludeCountries: ["IN"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
       initialCountry: "IN",
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
       preferredCountries: ['IN','US','UK'],
      // separateDialCode: true,
      utilsScript: "js/utils.js"
    });
         var checkdata = function(){
             var extension = $("#phone").intlTelInput("getExtension");
             var isValid = $("#phone").intlTelInput("isValidNumber");
             
             console.log(isValid);
             alert(extension);
             console.log(extension);
         }
  </script>
    </body>
</html>